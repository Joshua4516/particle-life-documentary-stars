# the terms i use in this documentary







**-SHIP-** ship is a craft of 2 or more particles more compact then a bug goes fast and sometimes slow



**-BUG-** a version of a ship made up of 3 or more types of particles normaly long and thin can go slow not fast



