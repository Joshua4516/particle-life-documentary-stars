# **This is a explanation for what this is**







this is a explanation for a simple program/website called particle life -[Website](https://sandbox-science.com/particle-life)- it is a in-depth explanation of every specie i could find and partical just realy everything also the json that comes with this you can use to get the same stuff i got if you go to my presets and press new preset and then import it



### IF YOU WANT TO REPLICATE THIS LISTEN IN

i have used tamper monkey to run a console command to get unlimited access to the website aka go pass normal limits for particle count the script will be stored in this zip to use it jsut copy paste the contents of the txt into a script into a script from tamper monkey its plug and play does work with 3d







### **IF YOU WANT MORE EXPLANATION**



watch this video its realy good and explains alot [the video](https://www.youtube.com/watch?v=SYDAcivFV-U&t=295s)

