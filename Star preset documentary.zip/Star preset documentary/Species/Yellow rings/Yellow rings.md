# **Yellow rings**

yellow rings are formed from light pink particle compressing yellow particles into rings they are very stable as long as they have a balanced ratio of particles other creatures get unstable no matter what eventually this. does not normal pink particles can make these rings split rapidly until theres only around 3 or so pink particles

