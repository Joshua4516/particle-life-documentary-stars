**PINK STAR ENTRY**



**-pink star field-** The beginning of the pink stars life span much like frog eggs these fields can vary from 2 to 6 baby pink stars sometimes more although rare. they are made of small amounts of blue and pink particles the field shape with dots come from the pink cushioning the blue particles and not allowing them to merge



**-baby pink star-** is made when a pink star field has either absorbed enough pink particles or a immature field is ran into by another creature rapidly forming. a baby pink star is made of 100 to 500 pink particles and 100 to 200 blue particles the star shape is most common although can be a plus shape if not enough blue particles are present the star shape comes from the blue particles pressing the pink particles into shape. extra info the plus shape variant after a while if it is not grown it will dissemble back into a field



**-fully grown pink star-** when a baby pink star absorbs excessive amounts of both blue particles and pink particles they become more defined as stars the plus variant that the baby version has is completely gone the fully grown version only stays grown for a bit before it becomes unstable and exploding normally birthing multiple baby pink stars rarely it makes a field do to the amount of particles it is comprised of



**-parasitized pink stars**- the upmost 80% of pink stars eventually get parasitized by dark blue clumps of particles rarely it can be a symbiosis. the reason symbiosis is rare is because most of the clumps shove the pink star around to much where it disassembles mostly into fields for the smaller stars when symbiosis is achieved its only 10 dark blue particles instead of 25 to 30 like the clumps contain it allows the start to grow indefinably until it becomes unstable

