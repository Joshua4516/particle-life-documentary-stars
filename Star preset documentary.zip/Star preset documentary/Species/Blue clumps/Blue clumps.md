# **BLUE CLUMPS**

blue clumps are relatively stationary. over time they become more dense container more and more dark blue particles, they also over time amass tons of rings of many different types of particles

