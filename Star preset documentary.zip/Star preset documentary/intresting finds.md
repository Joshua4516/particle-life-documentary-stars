# interesting stuff i have found with this preset

##### 







##### \-particle count changes-

the results can very based on how many particals you have on the partical count based on if the things stay in the lower version like fields for pink stars and so on the more particles faster results appear up to a point after it breaks



